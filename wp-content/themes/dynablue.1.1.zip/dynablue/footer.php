
            
        </div>
    </div>

	<div id="body_right">
		<div id="sidebars">
			<?php get_sidebar(); ?>
		</div>
	</div>

</div>
</div>
</div>

<div id="footer">
	<div id="footer_text">
    	<p>&copy; 2007. All Rights Reserved. <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></p>
		<p class="designed">Powered by <a href="http://wordpress.org/">WordPress</a> | Designed by <b><a href="http://www.webdesignlessons.com/">WebDesignLessons.com</a></b></p>
    </div>
</div>

		<?php wp_footer(); ?>


</div>

</body>
</html>
