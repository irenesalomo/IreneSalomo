
            
        </div>
    </div>

	<div id="body_right">
        <div id="sidebar_ads"><?php if(function_exists('theme_ads_show')) theme_ads_show(); ?></div>
		
		<div id="sidebars">
			<?php get_sidebar(); ?>
		</div>
	</div>

</div>
</div>
</div>

<div id="footer">
	<div id="footer_text">
    	<p>&copy; All Rights Reserved. <a href="<?php echo get_option('home'); ?>/"><?php bloginfo('name'); ?></a></p>
		<p class="designed">Powered by <a href="http://wordpress.org/">WordPress</a> | <b><a href="http://www.webdesignlessons.com/topics/wordpress-themes/">Wordpress Themes</a></b> by WebDesignLessons.com</p>
    </div>
</div>


		<?php wp_footer(); ?>


</div>

</body>
</html>
